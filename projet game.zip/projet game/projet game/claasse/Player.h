

#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "cocos2d.h"



class player
{
public:
    player(cocos2d::Layer* layer, int myLevel);
    player();
private:
    cocos2d::Size visibleSize;
    cocos2d::Vec2 origin;
    int direction;
    int height;
    cocos2d::Sprite* picopark;
    int myLevel;
public:

    void Left();
    void Right();
    void Up();
    void Down();

    //void keyPressed(cocos2d::EventKeyboard::KeyCode keyCode, cocos2d::Event* event);
};