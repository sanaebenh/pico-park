#ifndef _DEFINITIONS_H_
#define _DEFINITIONS_H_ 

#define DISPLAY_TIME_SPLASH_SCENE 3  // la scene Splash_Scene va etre afficher durant 3 second
#define TRANSITION_TIME 1   // la vitesse de transition entre les diferents scenes est de 1 
#define BALL_SPEED 0.1   // la vitesse du mouvement du ball 
#define CC_CALLBACK_2 
#define BALL_SPEED 0.1

#define LEFT 104
#define UP 100
#define DOWN 101
#define M 102
#define RIGHT 103
#define LEFT 104
#define XRIGHT 105
#define XUP 106
#define XXRIGHT 107
#define XXRIGHTM 108
#define LEFTM 109
#define SEGMENT_CODE_1 200
#define SEGMENT_CODE_2 201
#define SEGMENT_CODE_3 202
#define SEGMENT_CODE_4 203
#define SEGMENT_CODE_5 204
#define SEGMENT_CODE_6 205
#define SEGMENT_CODE_7 206



#endif // _DEFINITIONS_H_

