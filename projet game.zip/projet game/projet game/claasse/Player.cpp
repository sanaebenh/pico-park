

#include "Player.h"
#include "Definitions.h"




USING_NS_CC;

Player::Player(cocos2d::Layer* layer)
{
    visibleSize = Director::getInstance()->getVisibleSize();
    origin = Director::getInstance()->getVisibleOrigin();
    direction = LEFT;

    picopark = Sprite::create("pay.png");
    picopark->setPosition(Point(visibleSize.width * 0.1 + origin.x, visibleSize.height * 0.12 + origin.y));

    //creation de body 
  // auto picoparkbody  = PhysicsBody::createCircle(picopark->getContentSize().width / 2);
 //  picopark->setPhysicsBody(picoparkbody);
    layer->addChild(picopark);
    layer->addChild(picopark, 100);

    //auto action5 = JumpBy::create(2, Point(100, 0), 50, 1);
    //picopark->runAction(action5);




}
player::player()
{

}

// gestion du clavier
void Player::Left() {
    if (direction == RIGHT && height == DOWN) {
        auto action = MoveTo::create(BALL_SPEED, Point(visibleSize.width / 2 + origin.x - 100.0f, visibleSize.height / 2 + origin.y - 100.0f));
        this->picopark->runAction(action);
        this->direction = LEFT;
        this->segmentCode = SEGMENT_CODE_1;
    }
    else if (direction == XRIGHT && height == UP) {
        auto action = MoveTo::create(BALL_SPEED, Point(visibleSize.width / 2 + origin.x + 100.0f, visibleSize.height / 2 + origin.y + 150.0f));
        this->picopark->runAction(action);
        this->direction = RIGHT;
        this->segmentCode = SEGMENT_CODE_3;
    }

        else
            log("key left was pressed");

}
void Player::Right() {
    auto action2 = MoveTo::create(3, Vec2(200, 100));
    this->picopark->runAction(action2);
    direction = RIGHT;
}

void Player::Up() {
    auto action3 = MoveTo::create(BALL_SPEED, Point(visibleSize.width / 2 + origin.x + 100.0f, visibleSize.height / 2 + origin.y + 150.0f));
    picopark->runAction(action3);
}
void Player::Down() {

    auto action4 = MoveTo::create(BALL_SPEED, Point(visibleSize.width / 2 + origin.x + 100.0f, visibleSize.height / 2 + origin.y - 100.0f));
    picopark->runAction(action4);
}